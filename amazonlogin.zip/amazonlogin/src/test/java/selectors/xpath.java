package selectors;

import org.openqa.selenium.By;

public class xpath {
    public static String searchbar =   "//input[@id=\"twotabsearchtextbox\"]"  ;
     public static String itemsearch = "//input[@id=\"nav-search-submit-button\"]";
    public static String element =  "Noise Sense Bluetooth Wireless in Ear Earphones with Mic (Jet Black)";
    public static String boat = "//a[contains( .,'boAt Bassheads 100 in Ear Wired Earphones with Mic(Black)')] " ;
     public static String cart = "//input[@id=\"add-to-cart-button\"]";
     public static String gotocart="//a[@id=\"nav-cart\"]";
    public static String deleteitem =    "//input[@value=\"Delete\"]";
    public static String emptycart = "//*[@id=  \"sc-active-cart\"]/div/div /div/h1";


}